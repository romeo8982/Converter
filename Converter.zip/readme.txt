Wstępne wymagania:
Zainstalowana java 8 lub wyższa oraz dodana do zmienny środowiskowych systemu Windows.
 

Po wypakowaniu paczki Converter.zip uruchomić skrypt script.bat oraz udzielić zezwolnia. Efekt uruchomienie się serwisu w linii komend oraz uruchomienie się strony http://localhost:8080/, możliwe że będzie potrzebne odświerzenie strony (uruchamia się przed startem aplikacji) następnie można kożystać z witryny.
